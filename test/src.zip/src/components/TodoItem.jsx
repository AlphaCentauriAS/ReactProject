import React from 'react';

const TodoItem = ({ name }) => {
    
    return (
        <li>{name}</li>
    );
} 

export default TodoItem;