import React, { Component } from 'react';

class TodoForm extends Component {
    constructor() {
        super();

        this.state = {

        }
    }

    handleSubmit(e) {
        e.preventDefault();
    }

    handleInputChange(e) {
        console.log(e.target.value);
    }

    render() {
        return(
            <form onSubmit={this.handleSubmit.bind(this)}>
                <input type="text" onChange={this.handleInputChange.bind(this)}/>
                <button type="submit">Submit</button>
            </form>
        );
    }
}

export default TodoForm; 