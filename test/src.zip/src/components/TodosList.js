import React, { Component } from 'react';
import TodoItem from './TodoItem';

class TodosList extends Component {
    constructor(props) {
        super();
        this.state = {
        
        }
    }

    render() {
        let data = this.props.todos;
        return(
            <div>
                <ul>
                    {
                        data.map(todo => {
                            return (
                                <TodoItem name={todo} key={todo}/>
                            );
                        })
                    }
                </ul>
            </div>
        );
    }
}

export default TodosList;