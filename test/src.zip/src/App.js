import React, { Component } from 'react';
import './App.css';
import TodosList from './components/TodosList';
import TodoForm from './components/TodoForm';

class App extends Component {
  constructor(props) {
    super();
    this.state = {
        todos: [
            '1st todo',
            '2st todo',
            '3st todo'
        ]
    }
  }

  render() {
    return (
      <div className="App">
        <h1>ToDo App</h1>
        <TodoForm />
        <TodosList todos={this.state.todos}/>
      </div>
    );
  }
}

export default App;
